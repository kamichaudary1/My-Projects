var jQuery = $;

jQuery( document ).ready(function(){
  
  // asidebar active class add remove
  var selector = '.ip-asidebar ul li';
  jQuery(selector).on('click', function(){
    jQuery(this).toggleClass('active');
  });

  // aside bar list function

  // asidbar list add class to li that has child starts here
  jQuery('.ip-asidebar ul li').each(function(){
    var hasNestedItems = jQuery(this).find('li').length;
    if(hasNestedItems > 0){
        jQuery(this).addClass('parent');
    }
  });

  /*jQuery( ".ip-asidebar ul li.parent" ).click(function(e){
    e.stopPropagation();
    jQuery(this).toggleClass( "aside-list-active" );
  });*/

  // closing previous open li on current li click
  var asidebarLi = jQuery( ".ip-asidebar ul > li" );
    jQuery(asidebarLi).each(function (){
    // Set up onclick handler...
    jQuery(this).click(function (){
      // Cache reference to clicked item.
      var clicked = this;
      // Iterate through list of sub-menu items...
      for(i=0,c=asidebarLi.length;i<c;i++){

        // If current item is not the clicked item...
        if (asidebarLi[i] !== clicked){
          // Get reference to parent <li>, then remove the mm-opened class.
          var parent = jQuery(asidebarLi[i]).closest('li');
          jQuery(parent).removeClass('active');
        }
      }
    });
  });

});