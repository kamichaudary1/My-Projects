
jQuery( document ).ready(function(){

  // slick slider
  $('.btf4-slider').slick({
    centerMode: true,
    centerPadding: '60px',
    slidesToShow: 3,
    autoplay: true,
    autoplaySpeed: 3000,
    dots: true,
    infinite: true,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          centerMode: true,
          centerPadding: '0',
          slidesToShow: 1
        }
      },
      {
        breakpoint: 768,
        settings: {
          arrows: true,
          centerMode: true,
          centerPadding: '40px',
          slidesToShow: 1
        }
      }
    ]
  });

  // location row slider
  $('.single-item').slick({
    autoplaySpeed: 3000,
    dots: true,
  });

  jQuery( '.practicearea-mobile' ).slick({
    centerMode: true,
    arrows: false,
    centerPadding: '0px',
    slidesToShow: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    dots: true,
    infinite: true,
  });

  jQuery('.hp-partners-mobile').slick({
    centerMode: true,
    arrows: false,
    centerPadding: '0px',
    slidesToShow: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    dots: true,
    infinite: true,
  });

  // hp atf case results carousel
  jQuery('#carouselExampleFade').carousel({
    interval: 8000
  });

  // hp atf testimonials
  (function() {
    var quotes = $(".hp-atf-testimonials");
    var quoteIndex = -1;
    function showNextQuote() {
        ++quoteIndex;
        quotes.eq(quoteIndex % quotes.length)
            .fadeIn(2000)
            .delay(2000)
            .fadeOut(2000, showNextQuote);
    }
    showNextQuote(); 
  })();

  (function() {
    var quotes = $(".hp-mobileatf-testimonials");
    var quoteIndex = -1;
    function showNextQuote() {
        ++quoteIndex;
        quotes.eq(quoteIndex % quotes.length)
            .fadeIn(2000)
            .delay(2000)
            .fadeOut(2000, showNextQuote);
    }
    showNextQuote(); 
  })();

});
