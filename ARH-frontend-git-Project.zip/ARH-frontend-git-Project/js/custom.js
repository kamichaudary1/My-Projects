// atf height on desktop view
function hpATFHeight(){
  var winHeight = jQuery( window ).height();

  $( ".hp-atf-bg" ).height( winHeight );
}

$( document ).ready(function(){

  // header scroll function
  $(window).scroll(function(){    
      var scroll = $(window).scrollTop();
      //if ($(window).width() > 959) {  
        if (scroll >= 50) {
          $(".header").addClass("fix-header"); 
          $(".nav-button").addClass("active");
          $("body").addClass("scroll");
        }else{
          $(".header").removeClass("fix-header");
          $(".nav-button").removeClass("active");    
          $("body").removeClass("scroll");      
        }
      //}
  });

  // ip atf mobile slides
  (function() {
    var quotes = $(".ip-atf-slides");
    var quoteIndex = -1;
    function showNextQuote() {
        ++quoteIndex;
        quotes.eq(quoteIndex % quotes.length)
            .fadeIn(2000)
            .delay(2000)
            .fadeOut(2000, showNextQuote);
    }
    showNextQuote(); 
  })();

  // nav functions starts here
  $( '.nav ul li' ).each(function(){
      var hasNestedItems = $(this).find('li').length;
      if(hasNestedItems > 0){
          $(this).addClass('parent');
      }
  });

  $(".nav ul li.parent").click(function (e) {
    if($(window).width() < 991){
      //e.stopPropagation();
      $(this).toggleClass("item-active");  
      //return false;
    }
  });

  $( ".header .nav ul li" ).hover(function(){
    if($(window).width() > 991){
      $(this).toggleClass( "hovered" );
    }
  });

  // closing previous open li on current li click
  if($(window).width() < 991){
    var subMenuLI = $( ".nav ul > li.parent" );
    $(subMenuLI).each(function (){
      // Set up onclick handler...
      $(this).click(function (){
        // Cache reference to clicked item.
        var clicked = this;
        // Iterate through list of sub-menu items...
        for(i=0,c=subMenuLI.length;i<c;i++){

          // If current item is not the clicked item...
          if (subMenuLI[i] !== clicked){
            // Get reference to parent <li>, then remove the mm-opened class.
            var parent = $(subMenuLI[i]).closest('li');
            $(parent).removeClass('item-active');
            $(parent).removeClass('hovered');
          }
        }
      });
    });
  }

  $( ".nav-button" ).click(function(){
    $( this ).toggleClass( "change-navicon" );
    $( "body" ).toggleClass( "body-fixed" );
    $( ".header .nav ul li.parent" ).removeClass( "item-active" );
    $( ".header .nav ul li.parent" ).removeClass( "hovered" );
  });

  $( ".nav-button" ).click(function(){
    $( ".nav" ).toggleClass( "toggle-nav" );
  }); 

  // Gets the video src from the data-src on each button
  var $videoSrc;  
  $('.video-btn').click(function() {
      $videoSrc = $(this).data( "src" );
  });
  console.log($videoSrc);    
    
  // when the modal is opened autoplay it  
  $('#myModal').on('shown.bs.modal', function (e) {
      
  // set the video src to autoplay and not to show related video. Youtube related video is like a box of chocolates... you never know what you're gonna get
  $("#video").attr('src',$videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0" ); 
  })

  // calling functions
  hpATFHeight();
  AOS.init();
  AOS.init({ disable: 'mobile' });

  // bootstrap4 swipe on mobile
  !function(t){t.fn.bcSwipe=function(e){var n={threshold:50};return e&&t.extend(n,e),this.each(function(){function e(t){1==t.touches.length&&(u=t.touches[0].pageX,c=!0,this.addEventListener("touchmove",o,!1))}function o(e){if(c){var o=e.touches[0].pageX,i=u-o;Math.abs(i)>=n.threshold&&(h(),t(this).carousel(i>0?"next":"prev"))}}function h(){this.removeEventListener("touchmove",o),u=null,c=!1}var u,c=!1;"ontouchstart"in document.documentElement&&this.addEventListener("touchstart",e,!1)}),this}}($);
   
  // Swipe functions for Bootstrap Carousel
  $('.carousel').bcSwipe({ threshold: 50 });

  // location slider arrow
  $( ".btf15-slider .slick-prev" ).click(function(){
    $( this ).addClass( "large" );
    $( ".btf15-slider .slick-next" ).removeClass( "large" );
  });

  $( ".btf15-slider .slick-next" ).click(function(){
    $( this ).addClass( "large" );
    $( ".btf15-slider .slick-prev" ).removeClass( "large" );
  });


});

$( window ).resize(function() {
  hpATFHeight();
  
});
