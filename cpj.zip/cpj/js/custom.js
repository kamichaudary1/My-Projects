// practicearea heading fix on scroll
function practiceArea() {
    $(window).scroll(function() {
        if ($(window).width() > 767) {
            var t = $(window).scrollTop(),
                e = $(".btf-row2 .container").offset().top,
                o = $(".btf-row2 .container").height(),
                a = $(".btf2-title").height();
            t >= e && t < e + o - a ? $(".btf2-title").addClass("btf2-title-fixed") : $(".btf2-title").removeClass("btf2-title-fixed")
        }
    })
}

// adding class to header on scroll
function headerFixed() {
  $(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 80) {
        $(".header").addClass("header-fixed");
    }else {
        $(".header").removeClass("header-fixed");
    }
  });
}

$( document ).ready(function(){

  // adding class to header on mobile page scroll
  $(window).scroll(function(){    
      var scroll = $(window).scrollTop();

      // hp atf scroll fix buttons
        var winHeight = $( window ).height();
        var hpATF = winHeight;
        var innerpageHeight = $( ".ip-atf" ).height();
        if ( $(window).scrollTop() >= hpATF ) {
            $( ".atf-fix-buttons" ).addClass("show");
            $( "#draggable" ).addClass("show");
        }
        else {
            $( ".atf-fix-buttons" ).removeClass("show");
            $( "#draggable" ).removeClass("show");
        }

        // inner page atf fix buttons
        var innerpageHeight = $( ".ip-atf" ).height();
        if ( $(window).scrollTop() >= 365 ) {
            $( ".atf-fix-buttons" ).addClass("show");
            $( "#draggable" ).addClass("show");
        }
        else {
            $( ".atf-fix-buttons" ).removeClass("show");
            $( "#draggable" ).removeClass("show");
        }
      if ($(window).width() < 992) {  
        if (scroll >= 50) {
          $(".header").addClass("fix-header"); 
          $(".nav-button").addClass("active");
          $("body").addClass("scroll");
        }else{
          $(".header").removeClass("fix-header");
          $(".nav-button").removeClass("active");    
          $("body").removeClass("scroll");      
        }
      }
  });

  // nav functions starts here
  $( '.header .nav ul li' ).each(function(){
      var hasNestedItems = $(this).find('li').length;
      if(hasNestedItems > 0){
          $(this).addClass('parent');
      }
  });

  $(".header .nav ul li.parent").click(function (e) {
    if($(window).width() < 992){
      //e.stopPropagation();
      $(this).toggleClass("item-active");  
      //return false;
    }
  });

  // closing previous open li on current li click
  if($(window).width() < 992){
    var subMenuLI = $( ".header .nav ul > li.parent" );
    $(subMenuLI).each(function (){
      // Set up onclick handler...
      $(this).click(function (){
        // Cache reference to clicked item.
        var clicked = this;
        // Iterate through list of sub-menu items...
        for(i=0,c=subMenuLI.length;i<c;i++){

          // If current item is not the clicked item...
          if (subMenuLI[i] !== clicked){
            // Get reference to parent <li>, then remove the mm-opened class.
            var parent = $(subMenuLI[i]).closest('li');
            $(parent).removeClass('item-active');
            $(parent).removeClass('hovered');
          }
        }
      });
    });
  }

  // show-submenu from nav
  $( ".header .nav ul li.parent .sub-menu li.parent" ).click(function(){
    $( this ).toggleClass( "show-submenu" );
  });

  $( ".nav-button" ).click(function(){
    $( this ).toggleClass( "change-navicon" );
    $( "body" ).toggleClass( "body-fixed" );
    $( "header" ).toggleClass( "fix-header" );
    $( ".header .nav ul li.parent" ).removeClass( "item-active" );
    $( ".header .nav ul li.parent" ).removeClass( "hovered" );
    $( ".header .nav ul li.parent .sub-menu li.parent" ).removeClass( "show-submenu" );
    $( ".nav" ).toggleClass( "toggle-nav" );
  });

  // main popup onclick function
  $( ".ip-atf .ip-atf-buttons li:nth-child(2), .hp-atf-btns li:nth-child(2), .sticky-nav-outer ul li:nth-child(1), .atf-fix-buttons ul li" ).click(function(){
    $( ".main-popup" ).addClass( "show-modal" );
    $( "body" ).addClass( "show-overlay" );
  });

  $( ".ip-atf .consultation-btn" ).click(function(){
    $( ".main-popup" ).addClass( "show-modal" );
    $( "body" ).addClass( "show-overlay" );
  });

  $( ".main-popup .cross-btn " ).click(function(){
    $( ".main-popup" ).removeClass( "show-modal" );
    $( "body" ).removeClass( "show-overlay" );
  }); 

  // live chat closed
  $('.chatpopup .close-btn').click(function(){
    console.log("clicked");
    $( '.chatwrapper' ).removeClass('show');
  });

  // practice border hover effect
  // Scroll icon function Start
  pracItem = $('.practice-area .prac-item');
  dotVar = $('.practice-area .dot');
  $(pracItem).hover(function() {
      pracLen = $(pracItem).length;
      activeIndex = $(this).index();
      posDot = 0;
      for(var i = 0; i <= activeIndex; i++){
          posDot = posDot + $(pracItem[i]).height();
      }
      posDot = posDot - $(pracItem[activeIndex]).height();
      $(dotVar).css('top', posDot + 5);       
  })
  .on('mouseleave', function(){
      $(dotVar).css('top', '-5px');
  });

  // floating bg animation
  $(".floating-bg-inner").paroller({ factor: -0.2, factorXs: 0.1, type: 'foreground', direction: 'vertical' });

  // hp about slider arrow class add function
  $( ".btf-row3 .slick-prev" ).click(function(){
    $( ".btf-row3 .slick-next" ).removeClass( "active" );
    $( this ).addClass( "active" );
  });

  $( ".btf-row3 .slick-next" ).click(function(){
    $( ".btf-row3 .slick-prev" ).removeClass( "active" );
    $( this ).addClass( "active" );
  });

  // hp testimonial slider2
  $( ".slick-next.slick-arrow.slick-disabled" ).click(function(){
      $( ".btf-row5 .hp-testimonial-slider2 .slick-prev" ).show();
  });

  AOS.init();
  AOS.init({disable: 'mobile'});
  headerFixed();
  practiceArea();
  
});

// chat popup
$(window).bind('load', function(){    
  //console.log('Bind');
   /*if(localStorage.getItem('popState') != 'shown'){
      //console.log('Show');
        setTimeout(function(){
            $('.chatwrapper').addClass('show');
        }, 8000);
        localStorage.setItem('popState','shown')
    }else{
    //console.log('No Show');
  }
    $('.chatpopup .cta.no').click(function(e){
        e.preventDefault();
    console.log('No Click');
      $('.chatwrapper').removeClass('show');      
    });*/

    $( ".hp-atf .atf-slider, .ip-atf .ip-atf-testimonial" ).css( "display", "block");

});


