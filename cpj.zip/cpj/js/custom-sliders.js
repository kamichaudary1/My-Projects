$( document ).ready(function(){

	// hp atf testimonial slider
	// hp About slider
	$('.atf-slider').slick({
		arrows: false,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: false,
		infinite: true,
	});

	$('.about-slider').slick({
		arrows: true,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: false,
		infinite: true,
	});

	// btfrow2 mobile slider
	$('.practiceare-mobile, .hp-testimonial-slider').slick({
		centerMode: true,
		arrows: false,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: true,
		infinite: true,
	});

	// btfrow2 mobile slider
	$('.hp-testimonial-slider2').slick({
		arrows: true,
		dots: false,
		infinite: false,
		speed: 300,
		slidesToShow: 2,
		slidesToScroll: 2,
	});

	// about testimonial slider
	$('.choose-firm-slider').slick({
	  dots: false,
	  infinite: true,
	  arrows: true,
	  speed: 300,
	  slidesToShow: 1,
	  adaptiveHeight: true
	});
	
	// practice area mobile slides
	$('.practice-area-mobile').slick({
		centerMode: true,
		arrows: false,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: true,
		infinite: true,
	});

	// hp atf slider slider
	$('.hp-atf-testimonial').slick({
	  dots: false,
	  arrows: false,
	  infinite: true,
	  autoplay: true,
	  speed: 300,
	  slidesToShow: 1,
	  adaptiveHeight: true
	});

	// hp location slider
	$('.hp-locations-slider').slick({
	  dots: false,
	  arrows: true,
	  infinite: true,
	  autoplay: true,
	  speed: 300,
	  slidesToShow: 1,
	  adaptiveHeight: true
	});

	// hp atf slider slider
	$('.ip-atf-testimonial').slick({
	  dots: false,
	  arrows: false,
	  infinite: true,
	  autoplay: true,
	  speed: 300,
	  slidesToShow: 1,
	  adaptiveHeight: true
	});

	// btfrow8 desktop slider
	$('.btf-row8-slider').slick({
		centerMode: false,
		arrows: true,
		centerPadding: '0px',
		slidesToShow: 3,
		slidesToScroll: 1,
		autoplay: false,
		autoplaySpeed: 3000,
		dots: false,
		infinite: true,
		responsive: [
	    {
	      breakpoint: 767,
	      settings: {
	        slidesToShow: 2,
	        slidesToScroll: 1
	      }
	    },
	    {
	      breakpoint: 480,
	      settings: {
	        slidesToShow: 1,
	        slidesToScroll: 1
	      }
	    }
	  ]
	});

});
