function practiceArea() {
    $(window).scroll(function() {
        if ($(window).width() > 767) {
            var t = $(window).scrollTop(),
                e = $(".btf-row2-outer .container").offset().top,
                o = $(".btf-row2-outer .container").height(),
                a = $(".btf2-title").height();
            t >= e && t < e + o - a ? $(".btf2-title").addClass("btf2-title-fixed") : $(".btf2-title").removeClass("btf2-title-fixed")
        }
    })
}
$(document).ready(function() {
    pracItem = $(".practice-area .prac-item"), dotVar = $(".practice-area .dot"), $(pracItem).hover(function() {
        pracLen = $(pracItem).length, activeIndex = $(this).index(), posDot = 0;
        for (var t = 0; t <= activeIndex; t++) posDot += $(pracItem[t]).height();
        posDot -= $(pracItem[activeIndex]).height(), $(dotVar).css("top", posDot + 5)
    }).on("mouseleave", function() {
        $(dotVar).css("top", "-5px")
    }), practiceArea(), $(window).resize(function() {
        practiceArea()
    })
}), $(window).bind("load", function() {
    "shown" != localStorage.getItem("popState") && (setTimeout(function() {
        $(".chatwrapper").addClass("show")
    }, 8e3), localStorage.setItem("popState", "shown")), $(".chatpopup .cta.no").click(function(t) {
        t.preventDefault(), console.log("No Click"), $(".chatwrapper").removeClass("show")
    })
});