$( document ).ready(function(){

  // header scroll function
  $(window).scroll(function(){    
      var scroll = $(window).scrollTop();
      if ($(window).width() < 992) {  
        if (scroll >= 50) {
          $(".header").addClass("fix-header"); 
          $(".nav-button").addClass("active");
          $("body").addClass("scroll");
        }else{
          $(".header").removeClass("fix-header");
          $(".nav-button").removeClass("active");    
          $("body").removeClass("scroll");      
        }
      }
  });

  // nav functions starts here
  $( '.nav ul li' ).each(function(){
      var hasNestedItems = $(this).find('li').length;
      if(hasNestedItems > 0){
          $(this).addClass('parent');
      }
  });

  $(".nav ul li.parent").click(function (e) {
    if($(window).width() < 991){
      //e.stopPropagation();
      $(this).toggleClass("item-active");  
      //return false;
    }
  });

  // closing previous open li on current li click
  if($(window).width() < 991){
    var subMenuLI = $( ".nav ul > li.parent" );
    $(subMenuLI).each(function (){
      // Set up onclick handler...
      $(this).click(function (){
        // Cache reference to clicked item.
        var clicked = this;
        // Iterate through list of sub-menu items...
        for(i=0,c=subMenuLI.length;i<c;i++){

          // If current item is not the clicked item...
          if (subMenuLI[i] !== clicked){
            // Get reference to parent <li>, then remove the mm-opened class.
            var parent = $(subMenuLI[i]).closest('li');
            $(parent).removeClass('item-active');
            $(parent).removeClass('hovered');
          }
        }
      });
    });
  }

  // show-submenu from nav
  $( ".header .nav ul li.parent .sub-menu li.parent" ).click(function(){
    $( this ).toggleClass( "show-submenu" );
  });

  $( ".nav-button" ).click(function(){
    $( this ).toggleClass( "change-navicon" );
    $( "body" ).toggleClass( "body-fixed" );
    $( "header" ).toggleClass( "fix-header" );
    $( ".header .nav ul li.parent" ).removeClass( "item-active" );
    $( ".header .nav ul li.parent" ).removeClass( "hovered" );
    $( ".header .nav ul li.parent .sub-menu li.parent" ).removeClass( "show-submenu" );
    $( ".nav" ).toggleClass( "toggle-nav" );
  });


  // adding class btf5 sliders
  $( ".btf-row5-outer .slick-prev" ).click(function(){
    $( ".btf-row5-outer .slick-next" ).removeClass( "active" );
    $( this ).addClass( "active" );
  });

  $( ".btf-row5-outer .slick-next" ).click(function(){
    $( ".btf-row5-outer .slick-prev" ).removeClass( "active" );
    $( this ).addClass( "active" );
  });

  // adding class btf7 sliders
  $( ".btf-row7-outer .slick-prev" ).click(function(){
    $( ".btf-row7-outer .slick-next" ).removeClass( "active" );
    $( this ).addClass( "active" );
  });

  $( ".btf-row7-outer .slick-next" ).click(function(){
    $( ".btf-row7-outer .slick-prev" ).removeClass( "active" );
    $( this ).addClass( "active" );
  });

  // main popup onclick function
  $( ".hp-atf-bg .hp-atf-button" ).click(function(){
    $( ".main-popup" ).addClass( "show-modal" );
    $( "body" ).addClass( "show-overlay" );
  });

  $( ".main-popup .cross-btn " ).click(function(){
    $( ".main-popup" ).removeClass( "show-modal" );
    $( "body" ).removeClass( "show-overlay" );
  }); 

  // live chat closed
  $('.chatpopup .close-btn').click(function(){
    console.log("clicked");
    $( '.chatwrapper' ).removeClass('show');
  });

  // calling functions
  AOS.init();
  AOS.init({ disable: 'mobile' });

});