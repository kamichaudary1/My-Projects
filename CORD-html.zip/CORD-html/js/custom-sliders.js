$( document ).ready(function(){

	// btf row1 slider
	$('.btfrow1-slider').slick({
		centerMode: true,
		arrows: false,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: true,
		infinite: true,
	});

	// btfrow2 sliders
	$('.btfrow2-slider').slick({
		centerMode: true,
		arrows: false,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: true,
		infinite: true,
	});

	// btfrow2 mobile slider
	$('.btfrow2-mobile').slick({
		centerMode: true,
		arrows: true,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: true,
		infinite: true,
	});

	// about testimonial slider
	$('.one-time').slick({
	  dots: true,
	  infinite: true,
	  speed: 300,
	  slidesToShow: 1,
	  adaptiveHeight: true
	});
	
	// practice area slides
	$('.practice-area-mobile').slick({
		centerMode: true,
		arrows: false,
		centerPadding: '0px',
		slidesToShow: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		dots: true,
		infinite: true,
	});

	// ip atf slider slider
	$('.ip-settlements-slider').slick({
	  dots: false,
	  arrows: false,
	  infinite: true,
	  autoplay: true,
	  speed: 300,
	  slidesToShow: 1,
	  adaptiveHeight: true
	});

	// bio mobile logos
	$('.bio-mobile-logos').slick({
	  dots: false,
	  arrows: true,
	  infinite: true,
	  speed: 300,
	  slidesToShow: 1,
	  adaptiveHeight: true
	});

	// inner pages atf slider
	(function() {
		var quotes = $(".ip-atf-settlements");
		var quoteIndex = -1;
		function showNextQuote() {
		    ++quoteIndex;
		    quotes.eq(quoteIndex % quotes.length)
		        .fadeIn(2000)
		        .delay(2000)
		        .fadeOut(2000, showNextQuote);
		}
		showNextQuote(); 
	})();

	// bootstrap4 swipe on mobile
	!function(t){t.fn.bcSwipe=function(e){var n={threshold:50};return e&&t.extend(n,e),this.each(function(){function e(t){1==t.touches.length&&(u=t.touches[0].pageX,c=!0,this.addEventListener("touchmove",o,!1))}function o(e){if(c){var o=e.touches[0].pageX,i=u-o;Math.abs(i)>=n.threshold&&(h(),t(this).carousel(i>0?"next":"prev"))}}function h(){this.removeEventListener("touchmove",o),u=null,c=!1}var u,c=!1;"ontouchstart"in document.documentElement&&this.addEventListener("touchstart",e,!1)}),this}}($);

	// Swipe functions for Bootstrap Carousel
	$('.carousel').bcSwipe({ threshold: 50 });

	$('.carousel').carousel({
	  interval: 8000
	})

});
