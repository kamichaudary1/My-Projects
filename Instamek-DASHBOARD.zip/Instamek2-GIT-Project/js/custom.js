$( document ).ready(function(){

  // collapsable sidebar slimscroll function
  $('#collapsablebar-scroll').slimScroll({
      alwaysVisible: true
  });

  

  // adding field row on add more click
  $( ".mytask-addmore-btn" ).click(function(){
  	$( ".addmore-field-row" ).show();
  });
  
});